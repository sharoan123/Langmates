import '/flutter_flow/flutter_flow_util.dart';
import 'united_kingdom_widget.dart' show UnitedKingdomWidget;
import 'package:flutter/material.dart';

class UnitedKingdomModel extends FlutterFlowModel<UnitedKingdomWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    unfocusNode.dispose();
  }
}
