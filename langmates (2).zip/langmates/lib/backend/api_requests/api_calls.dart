import 'dart:convert';

import '/flutter_flow/flutter_flow_util.dart';
import 'api_manager.dart';

export 'api_manager.dart' show ApiCallResponse;

const _kPrivateApiFunctionName = 'ffPrivateApiCall';

/// Start Assembly API Group Code

class AssemblyAPIGroup {
  static String baseUrl = 'https://api.assemblyai.com/v2/';
  static Map<String, String> headers = {
    'Authorization': 'e42c91462daf41eca5fae4635443e7e0',
  };
  static TranscriptCall transcriptCall = TranscriptCall();
  static GetTranscriptionTextCall getTranscriptionTextCall =
      GetTranscriptionTextCall();
}

class TranscriptCall {
  Future<ApiCallResponse> call({
    String? audioUrl = '',
  }) async {
    final ffApiRequestBody = '''
{
  "audio_url": "$audioUrl"
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'transcript',
      apiUrl: '${AssemblyAPIGroup.baseUrl}/transcript',
      callType: ApiCallType.POST,
      headers: {
        'Authorization': 'e42c91462daf41eca5fae4635443e7e0',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      alwaysAllowBody: false,
    );
  }
}

class GetTranscriptionTextCall {
  Future<ApiCallResponse> call({
    String? id = '',
  }) async {
    return ApiManager.instance.makeApiCall(
      callName: 'getTranscriptionText',
      apiUrl: '${AssemblyAPIGroup.baseUrl}transcript/$id',
      callType: ApiCallType.GET,
      headers: {
        'Authorization': 'e42c91462daf41eca5fae4635443e7e0',
      },
      params: {
        'id': id,
      },
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      alwaysAllowBody: false,
    );
  }

  String? id(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.id''',
      ));
  String? text(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.text''',
      ));
  double? confidence(dynamic response) => castToType<double>(getJsonField(
        response,
        r'''$.confidence''',
      ));
  int? audioduration(dynamic response) => castToType<int>(getJsonField(
        response,
        r'''$.audio_duration''',
      ));
  bool? punctuate(dynamic response) => castToType<bool>(getJsonField(
        response,
        r'''$.punctuate''',
      ));
}

/// End Assembly API Group Code

class ApiPagingParams {
  int nextPageNumber = 0;
  int numItems = 0;
  dynamic lastResponse;

  ApiPagingParams({
    required this.nextPageNumber,
    required this.numItems,
    required this.lastResponse,
  });

  @override
  String toString() =>
      'PagingParams(nextPageNumber: $nextPageNumber, numItems: $numItems, lastResponse: $lastResponse,)';
}

String _serializeList(List? list) {
  list ??= <String>[];
  try {
    return json.encode(list);
  } catch (_) {
    return '[]';
  }
}

String _serializeJson(dynamic jsonVar, [bool isList = false]) {
  jsonVar ??= (isList ? [] : {});
  try {
    return json.encode(jsonVar);
  } catch (_) {
    return isList ? '[]' : '{}';
  }
}
