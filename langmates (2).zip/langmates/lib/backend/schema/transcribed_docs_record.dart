import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';

class TranscribedDocsRecord extends FirestoreRecord {
  TranscribedDocsRecord._(
    super.reference,
    super.data,
  ) {
    _initializeFields();
  }

  // "title" field.
  String? _title;
  String get title => _title ?? '';
  bool hasTitle() => _title != null;

  // "time" field.
  DateTime? _time;
  DateTime? get time => _time;
  bool hasTime() => _time != null;

  // "transciption" field.
  String? _transciption;
  String get transciption => _transciption ?? '';
  bool hasTransciption() => _transciption != null;

  void _initializeFields() {
    _title = snapshotData['title'] as String?;
    _time = snapshotData['time'] as DateTime?;
    _transciption = snapshotData['transciption'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('TranscribedDocs');

  static Stream<TranscribedDocsRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => TranscribedDocsRecord.fromSnapshot(s));

  static Future<TranscribedDocsRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => TranscribedDocsRecord.fromSnapshot(s));

  static TranscribedDocsRecord fromSnapshot(DocumentSnapshot snapshot) =>
      TranscribedDocsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static TranscribedDocsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      TranscribedDocsRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'TranscribedDocsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is TranscribedDocsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createTranscribedDocsRecordData({
  String? title,
  DateTime? time,
  String? transciption,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'title': title,
      'time': time,
      'transciption': transciption,
    }.withoutNulls,
  );

  return firestoreData;
}

class TranscribedDocsRecordDocumentEquality
    implements Equality<TranscribedDocsRecord> {
  const TranscribedDocsRecordDocumentEquality();

  @override
  bool equals(TranscribedDocsRecord? e1, TranscribedDocsRecord? e2) {
    return e1?.title == e2?.title &&
        e1?.time == e2?.time &&
        e1?.transciption == e2?.transciption;
  }

  @override
  int hash(TranscribedDocsRecord? e) =>
      const ListEquality().hash([e?.title, e?.time, e?.transciption]);

  @override
  bool isValidKey(Object? o) => o is TranscribedDocsRecord;
}
