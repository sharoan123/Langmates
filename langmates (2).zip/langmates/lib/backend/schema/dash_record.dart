import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';

class DashRecord extends FirestoreRecord {
  DashRecord._(
    super.reference,
    super.data,
  ) {
    _initializeFields();
  }

  // "email" field.
  String? _email;
  String get email => _email ?? '';
  bool hasEmail() => _email != null;

  // "yesorno" field.
  bool? _yesorno;
  bool get yesorno => _yesorno ?? false;
  bool hasYesorno() => _yesorno != null;

  void _initializeFields() {
    _email = snapshotData['email'] as String?;
    _yesorno = snapshotData['yesorno'] as bool?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('dash');

  static Stream<DashRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => DashRecord.fromSnapshot(s));

  static Future<DashRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => DashRecord.fromSnapshot(s));

  static DashRecord fromSnapshot(DocumentSnapshot snapshot) => DashRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static DashRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      DashRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'DashRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is DashRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createDashRecordData({
  String? email,
  bool? yesorno,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'email': email,
      'yesorno': yesorno,
    }.withoutNulls,
  );

  return firestoreData;
}

class DashRecordDocumentEquality implements Equality<DashRecord> {
  const DashRecordDocumentEquality();

  @override
  bool equals(DashRecord? e1, DashRecord? e2) {
    return e1?.email == e2?.email && e1?.yesorno == e2?.yesorno;
  }

  @override
  int hash(DashRecord? e) => const ListEquality().hash([e?.email, e?.yesorno]);

  @override
  bool isValidKey(Object? o) => o is DashRecord;
}
