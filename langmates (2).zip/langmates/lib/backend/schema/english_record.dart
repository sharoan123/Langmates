import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';

class EnglishRecord extends FirestoreRecord {
  EnglishRecord._(
    super.reference,
    super.data,
  ) {
    _initializeFields();
  }

  // "english_user" field.
  DocumentReference? _englishUser;
  DocumentReference? get englishUser => _englishUser;
  bool hasEnglishUser() => _englishUser != null;

  // "level" field.
  String? _level;
  String get level => _level ?? '';
  bool hasLevel() => _level != null;

  void _initializeFields() {
    _englishUser = snapshotData['english_user'] as DocumentReference?;
    _level = snapshotData['level'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('english');

  static Stream<EnglishRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => EnglishRecord.fromSnapshot(s));

  static Future<EnglishRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => EnglishRecord.fromSnapshot(s));

  static EnglishRecord fromSnapshot(DocumentSnapshot snapshot) =>
      EnglishRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static EnglishRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      EnglishRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'EnglishRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is EnglishRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createEnglishRecordData({
  DocumentReference? englishUser,
  String? level,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'english_user': englishUser,
      'level': level,
    }.withoutNulls,
  );

  return firestoreData;
}

class EnglishRecordDocumentEquality implements Equality<EnglishRecord> {
  const EnglishRecordDocumentEquality();

  @override
  bool equals(EnglishRecord? e1, EnglishRecord? e2) {
    return e1?.englishUser == e2?.englishUser && e1?.level == e2?.level;
  }

  @override
  int hash(EnglishRecord? e) =>
      const ListEquality().hash([e?.englishUser, e?.level]);

  @override
  bool isValidKey(Object? o) => o is EnglishRecord;
}
