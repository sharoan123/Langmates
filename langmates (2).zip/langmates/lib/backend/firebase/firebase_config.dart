import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: const FirebaseOptions(
            apiKey: "AIzaSyDX-Wk1LNyt2njzPfD9T2t7kQrtI_bX0ok",
            authDomain: "langmates-hxnuk6.firebaseapp.com",
            projectId: "langmates-hxnuk6",
            storageBucket: "langmates-hxnuk6.appspot.com",
            messagingSenderId: "807628666079",
            appId: "1:807628666079:web:88a793205d0f1f5f5a256a"));
  } else {
    await Firebase.initializeApp();
  }
}
