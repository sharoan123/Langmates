// Export pages
export '/account_profile_creation/auth_2_create/auth2_create_widget.dart'
    show Auth2CreateWidget;
export '/account_profile_creation/auth_2_login/auth2_login_widget.dart'
    show Auth2LoginWidget;
export '/account_profile_creation/auth_2_forgot_password/auth2_forgot_password_widget.dart'
    show Auth2ForgotPasswordWidget;
export '/account_profile_creation/auth_2_create_profile/auth2_create_profile_widget.dart'
    show Auth2CreateProfileWidget;
export '/account_profile_creation/auth_2_profile/auth2_profile_widget.dart'
    show Auth2ProfileWidget;
export '/list_lang/list_lang_widget.dart' show ListLangWidget;
export '/quiz2/quiz2_widget.dart' show Quiz2Widget;
export '/mal_module_beginner/mal_module_beginner_widget.dart'
    show MalModuleBeginnerWidget;
export '/eng_module_inter/eng_module_inter_widget.dart'
    show EngModuleInterWidget;
export '/mal_module_inter/mal_module_inter_widget.dart'
    show MalModuleInterWidget;
export '/language_selection/chat/chat_widget.dart' show ChatWidget;
export '/language_selection/level_eng/level_eng_widget.dart'
    show LevelEngWidget;
export '/language_selection/invite_users/invite_users_widget.dart'
    show InviteUsersWidget;
export '/language_selection/eng_reading_inter/eng_reading_inter_widget.dart'
    show EngReadingInterWidget;
export '/language_selection/mal_reading_inter/mal_reading_inter_widget.dart'
    show MalReadingInterWidget;
export '/language_selection/eng_reading_beginner/eng_reading_beginner_widget.dart'
    show EngReadingBeginnerWidget;
export '/language_selection/mal_reading_beginneer/mal_reading_beginneer_widget.dart'
    show MalReadingBeginneerWidget;
export '/quizpage2/quizpage2_widget.dart' show Quizpage2Widget;
export '/dashboard/dashboard_widget.dart' show DashboardWidget;
export '/speaking_english1/speaking_english1_widget.dart'
    show SpeakingEnglish1Widget;
export '/eng_module_beginner/eng_module_beginner_widget.dart'
    show EngModuleBeginnerWidget;
export '/kerala/kerala_widget.dart' show KeralaWidget;
export '/listening_mal_inter/listening_mal_inter_widget.dart'
    show ListeningMalInterWidget;
export '/mal_dash_beg/mal_dash_beg_widget.dart' show MalDashBegWidget;
export '/language_selection/level_mal/level_mal_widget.dart'
    show LevelMalWidget;
export '/list_lang_inter/list_lang_inter_widget.dart' show ListLangInterWidget;
export '/language_selection/culture_choosing/culture_choosing_widget.dart'
    show CultureChoosingWidget;
export '/recording/recording_widget.dart' show RecordingWidget;
export '/eng_dash_beginner/eng_dash_beginner_widget.dart'
    show EngDashBeginnerWidget;
export '/listening/listening_widget.dart' show ListeningWidget;
export '/united_kingdom/united_kingdom_widget.dart' show UnitedKingdomWidget;
export '/writing_eng_beginner/writing_eng_beginner_widget.dart'
    show WritingEngBeginnerWidget;
export '/speaking_malayalam1/speaking_malayalam1_widget.dart'
    show SpeakingMalayalam1Widget;
