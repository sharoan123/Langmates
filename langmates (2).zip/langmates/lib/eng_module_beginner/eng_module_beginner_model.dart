import '/flutter_flow/flutter_flow_util.dart';
import 'eng_module_beginner_widget.dart' show EngModuleBeginnerWidget;
import 'package:flutter/material.dart';

class EngModuleBeginnerModel extends FlutterFlowModel<EngModuleBeginnerWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    unfocusNode.dispose();
  }
}
