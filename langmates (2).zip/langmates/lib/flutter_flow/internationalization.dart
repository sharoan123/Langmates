import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

const _kLocaleStorageKey = '__locale_key__';

class FFLocalizations {
  FFLocalizations(this.locale);

  final Locale locale;

  static FFLocalizations of(BuildContext context) =>
      Localizations.of<FFLocalizations>(context, FFLocalizations)!;

  static List<String> languages() => ['en', 'ml'];

  static late SharedPreferences _prefs;
  static Future initialize() async =>
      _prefs = await SharedPreferences.getInstance();
  static Future storeLocale(String locale) =>
      _prefs.setString(_kLocaleStorageKey, locale);
  static Locale? getStoredLocale() {
    final locale = _prefs.getString(_kLocaleStorageKey);
    return locale != null && locale.isNotEmpty ? createLocale(locale) : null;
  }

  String get languageCode => locale.toString();
  String? get languageShortCode =>
      _languagesWithShortCode.contains(locale.toString())
          ? '${locale.toString()}_short'
          : null;
  int get languageIndex => languages().contains(languageCode)
      ? languages().indexOf(languageCode)
      : 0;

  String getText(String key) =>
      (kTranslationsMap[key] ?? {})[locale.toString()] ?? '';

  String getVariableText({
    String? enText = '',
    String? mlText = '',
  }) =>
      [enText, mlText][languageIndex] ?? '';

  static const Set<String> _languagesWithShortCode = {
    'ar',
    'az',
    'ca',
    'cs',
    'da',
    'de',
    'dv',
    'en',
    'es',
    'et',
    'fi',
    'fr',
    'gr',
    'he',
    'hi',
    'hu',
    'it',
    'km',
    'ku',
    'mn',
    'ms',
    'no',
    'pt',
    'ro',
    'ru',
    'rw',
    'sv',
    'th',
    'uk',
    'vi',
  };
}

class FFLocalizationsDelegate extends LocalizationsDelegate<FFLocalizations> {
  const FFLocalizationsDelegate();

  @override
  bool isSupported(Locale locale) {
    final language = locale.toString();
    return FFLocalizations.languages().contains(
      language.endsWith('_')
          ? language.substring(0, language.length - 1)
          : language,
    );
  }

  @override
  Future<FFLocalizations> load(Locale locale) =>
      SynchronousFuture<FFLocalizations>(FFLocalizations(locale));

  @override
  bool shouldReload(FFLocalizationsDelegate old) => false;
}

Locale createLocale(String language) => language.contains('_')
    ? Locale.fromSubtags(
        languageCode: language.split('_').first,
        scriptCode: language.split('_').last,
      )
    : Locale(language);

final kTranslationsMap = <Map<String, Map<String, String>>>[
  // auth_2_Create
  {
    'tj19if7h': {
      'en': 'LangMates',
      'ml': 'ലാംഗ്മേറ്റ്സ്',
    },
    '88zm2v39': {
      'en': 'Get Started',
      'ml': 'തുടങ്ങി',
    },
    '9oi3uoew': {
      'en': 'Create an account and start learning !',
      'ml': 'ഒരു അക്കൗണ്ട് സൃഷ്ടിച്ച് പഠിക്കാൻ ആരംഭിക്കുക!',
    },
    'y81fqeu9': {
      'en': 'Email',
      'ml': 'ഇമെയിൽ',
    },
    'unp7togn': {
      'en': 'Password',
      'ml': 'Password',
    },
    'zzw35yzr': {
      'en': 'Create Account',
      'ml': 'അക്കൗണ്ട് സൃഷ്ടിക്കുക',
    },
    'm0cdl9ys': {
      'en': 'Already have an account? ',
      'ml': 'ഇതിനകം ഒരു അക്കൗണ്ട് ഉണ്ടോ?',
    },
    'f88c0s3f': {
      'en': 'Sign in here',
      'ml': 'ഇവിടെ സൈൻ ഇൻ ചെയ്യുക',
    },
    'e6oh4u1b': {
      'en': 'Home',
      'ml': 'വീട്',
    },
  },
  // auth_2_Login
  {
    'kpbzvk1o': {
      'en': 'LangMates',
      'ml': 'ലാംഗ്മേറ്റ്സ്',
    },
    'lu5b74uf': {
      'en': 'Welcome Back',
      'ml': 'തിരികെ സ്വാഗതം',
    },
    'jhl2ti3u': {
      'en': 'Fil out the below details',
      'ml': 'ചുവടെയുള്ള വിശദാംശങ്ങൾ പൂരിപ്പിക്കുക',
    },
    'motttrm4': {
      'en': 'Email',
      'ml': 'ഇമെയിൽ',
    },
    '6wwlms1n': {
      'en': 'Password',
      'ml': 'Password',
    },
    '3va5380t': {
      'en': 'Sign In',
      'ml': 'സൈൻ ഇൻ',
    },
    'n3fmy0u1': {
      'en': 'Or sign in with',
      'ml': 'അല്ലെങ്കിൽ ഉപയോഗിച്ച് സൈൻ ഇൻ ചെയ്യുക',
    },
    'uovg4gm4': {
      'en': 'Continue with Google',
      'ml': 'Google-ൽ തുടരുക',
    },
    'vmmsyd49': {
      'en': 'Continue with Apple',
      'ml': 'ആപ്പിളിനൊപ്പം തുടരുക',
    },
    '1ouukhm9': {
      'en': 'Don\'t have an account?  ',
      'ml': 'അക്കൗണ്ട് ഇല്ലേ?',
    },
    'mp29brkq': {
      'en': 'Create Account',
      'ml': 'അക്കൗണ്ട് സൃഷ്ടിക്കുക',
    },
    '0wgueztr': {
      'en': 'Forgot password?',
      'ml': 'പാസ്വേഡ് മറന്നോ?',
    },
    'tkm3tyi8': {
      'en': 'Home',
      'ml': 'വീട്',
    },
  },
  // auth_2_ForgotPassword
  {
    '1btxx2di': {
      'en': 'LangMates',
      'ml': 'ലാംഗ്മേറ്റ്സ്',
    },
    '5lzty5ou': {
      'en': 'Forgot Password',
      'ml': 'പാസ്വേഡ് മറന്നോ',
    },
    'moawaspc': {
      'en': 'Please fill out your email',
      'ml': 'ദയവായി നിങ്ങളുടെ ഇമെയിൽ പൂരിപ്പിക്കുക',
    },
    'jxpo9p4q': {
      'en': 'Email',
      'ml': 'ഇമെയിൽ',
    },
    'm6junymf': {
      'en': 'Send Reset Link',
      'ml': 'റീസെറ്റ് ലിങ്ക് അയയ്ക്കുക',
    },
    '5qmoqfco': {
      'en': 'Home',
      'ml': 'വീട്',
    },
  },
  // auth_2_createProfile
  {
    'la9hs12p': {
      'en': 'LangMates',
      'ml': 'ലാംഗ്മേറ്റ്സ്',
    },
    'aubxktuj': {
      'en': 'Home',
      'ml': 'വീട്',
    },
  },
  // auth_2_Profile
  {
    'i8aafdxm': {
      'en': 'Your Account',
      'ml': 'നിങ്ങളുടെ അക്കൗണ്ട്',
    },
    'g2nwpgwd': {
      'en': 'Edit Profile',
      'ml': 'പ്രൊഫൈൽ എഡിറ്റ് ചെയ്യുക',
    },
    'dp46v1h3': {
      'en': 'App Settings',
      'ml': 'ആപ്പ് ക്രമീകരണങ്ങൾ',
    },
    'oxvm94dy': {
      'en': 'Support',
      'ml': 'പിന്തുണ',
    },
    '7ez5hfkv': {
      'en': 'Terms of Service',
      'ml': 'സേവന നിബന്ധനകൾ',
    },
    'vsyx4m9e': {
      'en': 'Log Out',
      'ml': 'ലോഗ് ഔട്ട് ചെയ്യുക',
    },
    '0hn3w1hs': {
      'en': 'Home',
      'ml': 'വീട്',
    },
  },
  // List_lang
  {
    'ommkqb7z': {
      'en': 'Languages Available',
      'ml': 'ഭാഷകൾ ലഭ്യമാണ്',
    },
    '3c240z77': {
      'en': '#',
      'ml': '#',
    },
    'hxssfoz3': {
      'en': 'Selected',
      'ml': 'തിരഞ്ഞെടുത്തു',
    },
    'ndsnthk7': {
      'en': 'English',
      'ml': 'ഇംഗ്ലീഷ്',
    },
    'y3g7vdrc': {
      'en': 'Malayalam',
      'ml': 'മലയാളം',
    },
    '50t3aqyn': {
      'en': 'Select Languages',
      'ml': 'ഭാഷകൾ തിരഞ്ഞെടുക്കുക',
    },
    'yzbafemc': {
      'en': 'Select languages and let\'s get started !',
      'ml': 'ഭാഷകൾ തിരഞ്ഞെടുക്കുക, നമുക്ക് ആരംഭിക്കാം!',
    },
    '07o9eq8p': {
      'en': 'Home',
      'ml': 'വീട്',
    },
  },
  // quiz2
  {
    'l91hv300': {
      'en': 'Question 2/2',
      'ml': 'ചോദ്യം 2/2',
    },
    '5rawfx4f': {
      'en': 'How\'s your day?',
      'ml': 'നിങ്ങളുടെ ദിവസം എങ്ങനെയുണ്ട്?',
    },
    '7jphkd1i': {
      'en': 'Did you experience anything out of the ordinary?',
      'ml': 'നിങ്ങൾക്ക് അസാധാരണമായ എന്തെങ്കിലും അനുഭവപ്പെട്ടിട്ടുണ്ടോ?',
    },
    'f4mevyhe': {
      'en': 'Incredible  😇',
      'ml': 'അവിശ്വസനീയം 😇',
    },
    'l567vdsx': {
      'en': 'Great 😃',
      'ml': 'ഗംഭീരം 😃',
    },
    'iqzuhb28': {
      'en': 'Good 🙂',
      'ml': 'കൊള്ളാം 🙂',
    },
    'gzz8qzdw': {
      'en': 'Okay 😕',
      'ml': 'ശരി 😕',
    },
    '7wa9zqcq': {
      'en': 'Really Bad 😞',
      'ml': 'ശരിക്കും മോശം 😞',
    },
    'q9xhemxo': {
      'en': 'Next Question',
      'ml': 'അടുത്ത ചോദ്യം',
    },
    'lihbj8g8': {
      'en': 'Daily Quiz',
      'ml': 'പ്രതിദിന ക്വിസ്',
    },
    '3wyyofqb': {
      'en': 'Home',
      'ml': 'വീട്',
    },
  },
  // mal_module_beginner
  {
    '4ghjt53x': {
      'en': 'Malayalam',
      'ml': 'മലയാളം',
    },
    's36x7ppx': {
      'en': 'Select Module',
      'ml': 'മൊഡ്യൂൾ തിരഞ്ഞെടുക്കുക',
    },
    'baiv2qqd': {
      'en': 'Reading',
      'ml': 'വായന',
    },
    'ndvlp8b7': {
      'en': 'Writing',
      'ml': 'എഴുത്തു',
    },
    'k4rm8t5n': {
      'en': 'Listening',
      'ml': 'കേൾക്കുന്നു',
    },
    'xbtnabj4': {
      'en': 'Speaking',
      'ml': 'ക്വിസ്',
    },
    'wj2ye1c3': {
      'en': 'LangMates',
      'ml': 'ലാംഗ്മേറ്റ്സ്',
    },
    'pmkwm41y': {
      'en': 'Home',
      'ml': 'വീട്',
    },
  },
  // eng_module_inter
  {
    'grmffehp': {
      'en': 'Modules',
      'ml': 'മൊഡ്യൂളുകൾ',
    },
    'ytremk9q': {
      'en': 'English',
      'ml': 'ഇംഗ്ലീഷ്',
    },
    'jwggz382': {
      'en': 'Select Module',
      'ml': 'മൊഡ്യൂൾ തിരഞ്ഞെടുക്കുക',
    },
    'r4d78sag': {
      'en': 'Reading',
      'ml': 'വായന',
    },
    'n15ppe11': {
      'en': 'Speaking',
      'ml': 'സംസാരിക്കുന്നു',
    },
    '6jln3bnd': {
      'en': 'Listening',
      'ml': 'കേൾക്കുന്നു',
    },
    'g6pf8zm3': {
      'en': 'Home',
      'ml': 'വീട്',
    },
  },
  // mal_module-inter
  {
    'bz1jhn8d': {
      'en': 'Modules',
      'ml': 'മൊഡ്യൂളുകൾ',
    },
    '9gbhr131': {
      'en': 'Malayalam',
      'ml': 'മലയാളം',
    },
    't1j78gj5': {
      'en': 'Select Module',
      'ml': 'മൊഡ്യൂൾ തിരഞ്ഞെടുക്കുക',
    },
    'o9d19gkn': {
      'en': 'Reading',
      'ml': 'വായന',
    },
    '2wxyprf7': {
      'en': 'Writing',
      'ml': 'സംസാരിക്കുന്നു',
    },
    'h9kaw88a': {
      'en': 'Listening',
      'ml': 'കേൾക്കുന്നു',
    },
    'jlhc9kme': {
      'en': 'Speaking',
      'ml': 'ക്വിസ്',
    },
    'k18tpt7n': {
      'en': 'Home',
      'ml': 'വീട്',
    },
  },
  // level_eng
  {
    '7cfzba8l': {
      'en': 'Beginner',
      'ml': 'തുടക്കക്കാരൻ',
    },
    'c724uc6n': {
      'en': 'Intermediate',
      'ml': 'ഇന്റർമീഡിയറ്റ്',
    },
    's4obosdu': {
      'en': 'Choose your level',
      'ml': 'നിങ്ങളുടെ ലെവൽ തിരഞ്ഞെടുക്കുക',
    },
    'xuibexs7': {
      'en': 'Home',
      'ml': 'വീട്',
    },
  },
  // invite_users
  {
    'nc9iltb6': {
      'en': 'Chat',
      'ml': 'ചാറ്റ്',
    },
    'v0ga82i2': {
      'en': 'Home',
      'ml': 'വീട്',
    },
  },
  // eng_reading_inter
  {
    'bdm6j7d2': {
      'en': 'Reading - 1',
      'ml': 'വായന - 1',
    },
    '1ef6zvgh': {
      'en':
          'Yoruba Towns\nA. The Yoruba people of Nigeria classify their towns in two ways. Permanent towns with their own governments are called “ilu”, whereas temporary settlements, set up to support work in the country are “aba”. Although ilu tend to be larger than aba, the distinction is not one of size, some aba are large, while declining ilu can be small, but of purpose. There is no “typical” Yoruba town, but some features are common to most towns.',
      'ml':
          'യൊറൂബ പട്ടണങ്ങൾ\nഎ. നൈജീരിയയിലെ യൊറൂബ ജനങ്ങൾ തങ്ങളുടെ പട്ടണങ്ങളെ രണ്ട് തരത്തിൽ തരംതിരിച്ചിട്ടുണ്ട്. സ്വന്തം ഗവൺമെൻ്റുകളുള്ള സ്ഥിരമായ പട്ടണങ്ങളെ \"ഇലു\" എന്ന് വിളിക്കുന്നു, അതേസമയം രാജ്യത്തെ ജോലിയെ പിന്തുണയ്ക്കുന്നതിനായി സജ്ജീകരിച്ച താൽക്കാലിക സെറ്റിൽമെൻ്റുകളെ \"അബ\" എന്ന് വിളിക്കുന്നു. ഇലു അബയേക്കാൾ വലുതായിരിക്കുമെങ്കിലും, വ്യത്യാസം വലുപ്പത്തിലല്ല, ചില അബ വലുതാണ്, അതേസമയം ഇലു കുറയുന്നത് ചെറുതായിരിക്കാം, പക്ഷേ ഉദ്ദേശ്യത്തോടെയാണ്. \"സാധാരണ\" യൊറൂബ പട്ടണമില്ല, എന്നാൽ ചില സവിശേഷതകൾ മിക്ക പട്ടണങ്ങളിലും സാധാരണമാണ്.',
    },
    'z0npzpze': {
      'en': 'Match the correct heading to the paragraph.\n\n\n ',
      'ml': 'ഖണ്ഡികയുമായി ശരിയായ തലക്കെട്ട് പൊരുത്തപ്പെടുത്തുക.',
    },
    'omj4c38x': {
      'en': 'Town facilities',
      'ml': 'നഗര സൗകര്യങ്ങൾ',
    },
    '7hbxt0vb': {
      'en': ' Urban divisions',
      'ml': 'നഗര ഡിവിഷനുകൾ',
    },
    'f1dcqwrh': {
      'en': 'Colonisation',
      'ml': 'കോളനിവൽക്കരണം',
    },
    '3f5yrj8x': {
      'en': 'Architectural home styles',
      'ml': 'വാസ്തുവിദ്യാ ഭവന ശൈലികൾ',
    },
    'zf1k3nut': {
      'en': 'Types of settlements',
      'ml': 'സെറ്റിൽമെൻ്റുകളുടെ തരങ്ങൾ',
    },
    'bwbix02y': {
      'en': 'Back to Dashboard',
      'ml': 'ഡാഷ്‌ബോർഡിലേക്ക് മടങ്ങുക',
    },
    'lvdjgq8z': {
      'en': 'Home',
      'ml': 'വീട്',
    },
  },
  // mal-reading_inter
  {
    '2fo2ld6r': {
      'en': 'വായന - 1',
      'ml': 'വായന - 1',
    },
    '151xaqyt': {
      'en':
          'നൈജീരിയയിലെ യൊറുബ ജനങ്ങൾ തങ്ങളുടെ സ്ഥലങ്ങൾ രണ്ടായി വിഭാഗിക്കുന്നു - സ്ഥിരമായ നഗരങ്ങൾ \"ഇലു\" എന്നുകൊണ്ടുള്ളതും, കാര്യത്തില്‍ പണിക്കെടുക്കുന്ന \"അബ\" ആയിരിക്കുന്നതും. \"ഇലു\" കൂടുതല്‍ വലുതായിരിക്കുകയും, \"അബ\" പരാജയപ്പെടുന്ന ഇലുകളെക്കുറിച്ച് കുറച്ചു അല്ലെങ്കിൽ ചിറകുകുറഞ്ഞവയായിരിക്കുകയും. ഇലുകൾ വളർത്തുന്ന വലുതായ നഗരങ്ങളാകുന്നതും, പരാജയപ്പെടുന്ന ഇലുകൾ ചിറകുകുറഞ്ഞവയാകുന്നതും ചില ലക്ഷണങ്ങൾ സാമാന്യമാണ്. യൊറുബ നഗരങ്ങൾക്ക് \"സാധാരണ\" എന്നു പറയുന്നത്, അനേകം നഗരങ്ങളിലും പ്രചാരമുള്ള അവയുടെ സാമാന്യലക്ഷണങ്ങൾ അനുഭവപ്പെടുന്നു.',
      'ml':
          'നൈജീരിയയിലെ യൊറുബ ജനങ്ങൾ തങ്ങളുടെ സ്ഥലങ്ങൾ രണ്ടായി വിഭാഗിക്കുന്നു - സ്ഥിരമായ നഗരങ്ങൾ \"ഇലു\" എന്നുകൊണ്ടുള്ളതും, കാര്യത്തിൽ പണിയെടുക്കുന്ന \"അബ\" ആയിരിക്കുന്നതും. \"ഇലു\" കൂടുതൽ വലുതായിരിക്കുകയും, \"അബ\" പരാജയപ്പെടുന്ന ഇലകൾ കുറച്ചു അല്ലെങ്കിൽ ചിറകുകുറഞ്ഞവയായിരിക്കുകയും ചെയ്യും. ഇലകൾ വളർത്തുന്നത് വലുതായ നഗരങ്ങളാകുന്നതും, പരാജയപ്പെടുന്ന ഇലകൾ ചിറകുകുറഞ്ഞവയാകുന്നതും ചില ലക്ഷണങ്ങൾ സാധാരണമാണ്. യൊറുബ നഗരങ്ങൾക്ക് \"സാധാരണ\" എന്ന് പറയുന്നത്, അനേകം നഗരങ്ങളിലും പ്രചാരമുള്ള അവയുടെ സാമാന്യലക്ഷണങ്ങൾ അനുഭവപ്പെടുന്നു.',
    },
    'd2im2ybr': {
      'en': 'ശരിയായ ശീർഷകം തിരഞ്ഞെടുക്കുക',
      'ml': 'ശരിയായ ശീർഷകം തിരഞ്ഞെടുക്കുക',
    },
    '69jwew6r': {
      'en': 'നഗര സൗകര്യങ്ങൾ',
      'ml': 'നഗര സൗകര്യങ്ങൾ',
    },
    'pcbkmx46': {
      'en': 'നഗര പ്രദേശങ്ങൾ',
      'ml': 'നഗര പ്രദേശങ്ങൾ',
    },
    'mp8rfmf5': {
      'en': 'ഉപനിവേശനം',
      'ml': 'ഉപനിവേശനം',
    },
    'n8vhct0d': {
      'en': 'ആര്‍ക്കിടെക്ചറല്‍ ഹോം ശൈലികള്‍',
      'ml': 'ആർക്കിടെക്ചരൽ ഹോം ശൈലികൾ',
    },
    'lqe9jwp6': {
      'en': 'തരങ്ങളായ വാസസ്ഥലങ്ങൾ',
      'ml': 'തരങ്ങളായ വാസസ്ഥലങ്ങൾ',
    },
    'iis49w21': {
      'en': 'Home',
      'ml': 'വീട്',
    },
  },
  // eng_reading_beginner
  {
    '3cxrrykp': {
      'en': 'Reading - 1',
      'ml': 'വായന - 1',
    },
    '4u3sv3pm': {
      'en':
          'I wake up at 7 AM every day. After that, I have breakfast and get ready for work. I leave the house at 8:30 AM and take the bus to my office. I work from 9 AM to 5 PM. In the evening, I go to the gym for an hour. Finally, I go home, have dinner, and go to bed at 10:30 PM.',
      'ml':
          'ഞാൻ എല്ലാ ദിവസവും രാവിലെ 7 മണിക്ക് ഉണരും. അത് കഴിഞ്ഞ് ഞാൻ പ്രാതൽ കഴിച്ച് ജോലിക്ക് തയ്യാറായി. ഞാൻ 8:30 AM ന് വീട്ടിൽ നിന്ന് പുറപ്പെട്ട് എൻ്റെ ഓഫീസിലേക്ക് ബസിൽ പോകുന്നു. ഞാൻ 9 AM മുതൽ 5 PM വരെ ജോലി ചെയ്യുന്നു. വൈകുന്നേരം, ഞാൻ ഒരു മണിക്കൂർ ജിമ്മിൽ പോകുന്നു. അവസാനം, ഞാൻ വീട്ടിൽ പോയി അത്താഴം കഴിച്ച് രാത്രി 10:30 ന് ഉറങ്ങാൻ പോകുന്നു.',
    },
    'zdlv27yq': {
      'en': 'Choose correct answer\n\n\n ',
      'ml': 'ശരിയായ ഉത്തരം തിരഞ്ഞെടുക്കുക',
    },
    'jydl7kq9': {
      'en': '7:AM',
      'ml': '7:AM',
    },
    'e3gij9qa': {
      'en': 'Take a bus',
      'ml': 'ഒരു ബസ്സില് കയറുക',
    },
    'pp4y5o9x': {
      'en': '9:30 PM',
      'ml': '9:30 PM',
    },
    '0j1hdzfe': {
      'en': 'What time does the person wake up?',
      'ml': 'ഏത് സമയത്താണ് ഒരു വ്യക്തി ഉണരുന്നത്?',
    },
    '99i15nar': {
      'en': '10:AM',
      'ml': '10:AM',
    },
    '1vaee1jw': {
      'en': 'How does the person go to work?',
      'ml': 'ഒരു വ്യക്തി എങ്ങനെ ജോലിക്ക് പോകുന്നു?',
    },
    'fo4jgdsd': {
      'en': 'By car',
      'ml': 'കാറിൽ',
    },
    'kqn2bqq9': {
      'en': 'What time does the person go to bed?',
      'ml': 'ഏത് സമയത്താണ് ഒരു വ്യക്തി ഉറങ്ങാൻ പോകുന്നത്?',
    },
    '2r2t97fs': {
      'en': '10:30 PM',
      'ml': '10:30 PM',
    },
    '8mju2sz1': {
      'en': 'Done',
      'ml': 'ചെയ്തു',
    },
    'ak3obh5f': {
      'en': 'Home',
      'ml': 'വീട്',
    },
  },
  // mal_reading_beginneer
  {
    '4fyy6xgo': {
      'en': 'വായന - 1',
      'ml': 'വായന - 1',
    },
    'mdfoginw': {
      'en':
          'ഒരു പട്ടണത്തിനടുത്തുള്ള ഒരു കാട്ടിൽ ഒരു കാക്ക താമസിച്ചിരുന്നു. കാക്ക വളരെ നേരം യാത്ര ചെയ്തിരുന്നതിനാൽ അവന് വളരെ ദാഹിച്ചു. കുടിക്കാൻ വെള്ളത്തിനായി ചുറ്റും നോക്കിയെങ്കിലും ജലസ്രോതസ്സുകൾ കണ്ടെത്താനായില്ല.വെള്ളമില്ലാത്തതിനാൽ കാക്കയ്ക്ക് തളർച്ച അനുഭവപ്പെട്ടു തുടങ്ങി. അവൻ വെള്ളത്തിനായി തിരച്ചിൽ തുടങ്ങി. അവൻ കാട്ടിലും അടുത്തുള്ള പട്ടണത്തിലും എല്ലാം പറന്നു. നഗരം ചുറ്റിയ ശേഷം കാക്ക ഒരു വീട് കണ്ടു, വീട്ടിൽ വെള്ളമുണ്ടെന്ന് കരുതി.വീട്ടിലെത്തിയപ്പോൾ കണ്ടത് ഒരു പാത്രം നിറയെ വെള്ളം. അവൻ വളരെ സന്തോഷവതിയായി. ',
      'ml':
          'ഒരു പട്ടണത്തിനടുത്തുള്ള ഒരു കാട്ടിൽ ഒരു കാക്ക താമസിച്ചിരുന്നു. കാക്ക വളരെ നേരം യാത്ര ചെയ്തിരുന്നതിനാൽ അവന് വളരെ ദാഹിച്ചു. കുടിക്കാൻ വെള്ളത്തിനായി ചുറ്റും നോക്കിയെങ്കിലും ജലസ്രോതസ്സുകൾ കണ്ടെത്താനായില്ല.വെള്ളമില്ലാത്തതിനാൽ കാക്കയ്ക്ക് തളർച്ച അനുഭവപ്പെട്ടു തുടങ്ങി. അവൻ വെള്ളത്തിനായി തിരച്ചിൽ തുടങ്ങി. അവൻ കാട്ടിലും അടുത്തുള്ള പട്ടണത്തിലും എല്ലാം പറന്നു. നഗരം ചുറ്റിയ ശേഷം കാക്ക ഒരു വീട് കണ്ടു, വീട്ടിൽ വെള്ളമുണ്ടെന്ന് കരുതി.വീട്ടിലെത്തിയപ്പോൾ കണ്ടത് ഒരു പാത്രം നിറയെ വെള്ളം. അവൻ വളരെ സന്തോഷവതിയായി.',
    },
    'ivz2ouk4': {
      'en': '\nകാക്ക എവിടെയാണ് എല്ലാം ആണും വെള്ളം അന്വേഷിച്ചു പോയത്?',
      'ml': 'കാക്ക എവിടെയാണ് എല്ലാം ആണും വെള്ളം അന്വേഷിച്ചു പോയത്?',
    },
    'h5yf63vn': {
      'en': 'കാട്ടിലും അടുത്തുള്ള പട്ടണത്തിലും',
      'ml': 'കാട്ടിലും അടുത്തുള്ള പട്ടണത്തിലും',
    },
    'frac5zpi': {
      'en': 'ഭക്ഷണശാല',
      'ml': 'ഭക്ഷണശാല',
    },
    'dwtr6xrv': {
      'en': 'വീട്',
      'ml': 'വീട്',
    },
    'fby7fhrs': {
      'en': 'ഓഫീസ് ',
      'ml': 'ഓഫീസ്',
    },
    'pn6gcr3u': {
      'en': 'ആശുപത്രി',
      'ml': 'ആശുപത്രി',
    },
    '5a1a98s2': {
      'en': 'Home',
      'ml': 'വീട്',
    },
  },
  // quizpage2
  {
    '8m6qi7dd': {
      'en': 'Question 1/2',
      'ml': 'ചോദ്യം 1/2',
    },
    'gcx25nu3': {
      'en': 'How is your mood?',
      'ml': 'നിങ്ങളുടെ മാനസികാവസ്ഥ എങ്ങനെ ആണ്?',
    },
    'u4abjcxf': {
      'en': 'On a scale of 1 - 3 how are you feeling today?',
      'ml': '1 - 3 സ്കെയിലിൽ ഇന്ന് നിങ്ങൾക്ക് എങ്ങനെ തോന്നുന്നു?',
    },
    'pltcgtxb': {
      'en': 'Let\'s Gooo!',
      'ml': 'അടുത്ത ചോദ്യം',
    },
    'vibzst7o': {
      'en': 'Daily Quiz',
      'ml': 'പ്രതിദിന ക്വിസ്',
    },
    'va02ep91': {
      'en': 'Home',
      'ml': 'വീട്',
    },
  },
  // dashboard
  {
    'omit6cmw': {
      'en': 'Find your task...',
      'ml': 'നിങ്ങളുടെ ചുമതല കണ്ടെത്തുക...',
    },
    'o0ao00ob': {
      'en': 'Categories',
      'ml': 'വിഭാഗങ്ങൾ',
    },
    'vcg6kesc': {
      'en': 'Modules and Languges',
      'ml': 'ചാറ്റുകൾ',
    },
    'kscl8hav': {
      'en': '30%',
      'ml': '30%',
    },
    '8rqbk52r': {
      'en': 'Culture  Check',
      'ml': 'സംസ്കാര പരിശോധന',
    },
    'nf7boofd': {
      'en': '30%',
      'ml': '30%',
    },
    'dkdpz76z': {
      'en': 'Home',
      'ml': 'വീട്',
    },
  },
  // Speaking_English1
  {
    '2ypc1k0p': {
      'en': 'Speaking - 1',
      'ml': 'സംസാരിക്കുന്നത് - 1',
    },
    'ffq041uy': {
      'en':
          'The geography of the United States exerts a profound influence on its people and culture in many ways. Specifically, the fact that it is close to other countries, has a variety of landscapes, and contributes significiantly to global warming has shaped American culture.',
      'ml': 'ചിത്രം തിരിച്ചറിഞ്ഞ് സംസാരിക്കുക',
    },
    'x8fxqtqj': {
      'en': 'Done',
      'ml': '',
    },
    '6aqjeq8t': {
      'en': 'Try speaking the above passage along with the given audio clip:',
      'ml': '',
    },
    'ia5d7ly7': {
      'en': 'Home',
      'ml': 'വീട്',
    },
  },
  // eng_module_beginner
  {
    '3eloq0hq': {
      'en': 'Modules',
      'ml': 'മൊഡ്യൂളുകൾ',
    },
    'yp1mi3ly': {
      'en': 'English',
      'ml': 'ഇംഗ്ലീഷ്',
    },
    'em8srf65': {
      'en': 'Select Module',
      'ml': 'മൊഡ്യൂൾ തിരഞ്ഞെടുക്കുക',
    },
    'ols7rt7v': {
      'en': 'Reading',
      'ml': 'വായന',
    },
    'tcwm3968': {
      'en': 'Writing',
      'ml': 'സംസാരിക്കുന്നു',
    },
    'r9p8v9a9': {
      'en': 'Listening',
      'ml': 'കേൾക്കുന്നു',
    },
    '6zcjx261': {
      'en': 'Quiz',
      'ml': 'ക്വിസ്',
    },
    'ng9vdzo4': {
      'en': 'Home',
      'ml': 'വീട്',
    },
  },
  // Kerala
  {
    'kkyb8lw6': {
      'en': 'Kerala',
      'ml': 'കേരളം',
    },
    'cmzjbrdh': {
      'en': 'Malayalam',
      'ml': 'മലയാളം',
    },
    '233eogl0': {
      'en':
          'The culture of Kerala is reflected in its cuisine, clothing, art, and dance. The state\'s architecture is marked by intricately carved temples and traditional wooden homes, while its literature and art forms like Kathakali and Mohiniyattam have gained attention all over the world. Kathakali- It is one of the most famous dance forms of India. It is a combination of Opera, ballet, and masque.\nThe region is also famous for its Sadhya, served at the Hindu festival Onam and consisting of boiled rice and a host of vegetarian dishes on a banana leaf. Kerala cuisine also features a lot of sea food like fish, prawns, mussels and crabs because of its long coastline.\n',
      'ml':
          'കേരളത്തിൻ്റെ സംസ്കാരം അതിൻ്റെ പാചകരീതിയിലും വസ്ത്രത്തിലും കലയിലും നൃത്തത്തിലും പ്രതിഫലിക്കുന്നു. സംസ്ഥാനത്തിൻ്റെ വാസ്തുവിദ്യയിൽ സങ്കീർണ്ണമായ കൊത്തുപണികളുള്ള ക്ഷേത്രങ്ങളും പരമ്പരാഗത തടി വീടുകളും അടയാളപ്പെടുത്തുന്നു, അതേസമയം കഥകളി, മോഹിനിയാട്ടം തുടങ്ങിയ സാഹിത്യങ്ങളും കലാരൂപങ്ങളും ലോകമെമ്പാടും ശ്രദ്ധ നേടിയിട്ടുണ്ട്. കഥകളി- ഇന്ത്യയിലെ ഏറ്റവും പ്രശസ്തമായ നൃത്തരൂപങ്ങളിലൊന്നാണിത്. ഇത് ഓപ്പറ, ബാലെ, മാസ്ക് എന്നിവയുടെ സംയോജനമാണ്.\nഹിന്ദു ഉത്സവമായ ഓണത്തിൽ വിളമ്പുന്ന സദ്യയ്ക്കും ഈ പ്രദേശം പ്രസിദ്ധമാണ്, അതിൽ പുഴുങ്ങിയ ചോറും വാഴയിലയിൽ ധാരാളം സസ്യാഹാരങ്ങളും അടങ്ങിയിട്ടുണ്ട്. നീണ്ട കടൽത്തീരമായതിനാൽ മത്സ്യം, കൊഞ്ച്, ചിപ്പികൾ, ഞണ്ട് എന്നിങ്ങനെ ധാരാളം കടൽ ഭക്ഷണങ്ങളും കേരള ഭക്ഷണരീതിയിൽ ഉണ്ട്.',
    },
    'ecd9tevk': {
      'en': 'https://www.youtube.com/watch?v=wcXvvp1SFJc',
      'ml': '',
    },
    'if270ayy': {
      'en': 'Home',
      'ml': 'വീട്',
    },
  },
  // listening_mal_inter
  {
    'w29zzzwd': {
      'en': 'വായന - 1',
      'ml': 'വായന - 1',
    },
    'ahf3yimw': {
      'en':
          'ഈ കേൾക്കുന്ന ശബ്ദ ശകലത്തിൽ പറയുന്ന വാക്കിന്റെ അർത്ഥം വരുന്ന ഉത്തരം തിരഞ്ഞെടുക്കുക :',
      'ml':
          'ഈ കേൾക്കുന്ന ശബ്ദ ശകലത്തിൽ പറയുന്ന വാക്കിൻ്റെ അർത്ഥം വരുന്ന ഉത്തരം തിരഞ്ഞെടുക്കുക :',
    },
    'rvqzov6h': {
      'en': 'Happy Birthday!',
      'ml': 'ജന്മദിനാശംസകൾ!',
    },
    'vpcp2z5d': {
      'en': 'Good Luck!',
      'ml': 'നല്ലതുവരട്ടെ!',
    },
    '9rlbqda3': {
      'en': 'Congratulation!',
      'ml': 'അഭിനന്ദനങ്ങൾ!',
    },
    'p84y26xc': {
      'en': 'Cheers!',
      'ml': 'ചിയേഴ്സ്!',
    },
    '6rrxbjie': {
      'en': 'I am pleased to meet you.',
      'ml': 'നിങ്ങളെ കണ്ടതിൽ എനിക്ക് സന്തോഷമുണ്ട്.',
    },
    'npv30w1n': {
      'en': 'Home',
      'ml': 'വീട്',
    },
  },
  // mal_dash_beg
  {
    'gnef4p5f': {
      'en': 'Find your task...',
      'ml': 'നിങ്ങളുടെ ചുമതല കണ്ടെത്തുക...',
    },
    'dg7xqr2n': {
      'en': 'Categories',
      'ml': 'വിഭാഗങ്ങൾ',
    },
    'kovr3vef': {
      'en': 'Modules and Languges',
      'ml': 'ചാറ്റുകൾ',
    },
    'ot618rao': {
      'en': '30%',
      'ml': '30%',
    },
    'ilda0ioa': {
      'en': 'Culture  Check',
      'ml': 'സംസ്കാര പരിശോധന',
    },
    '3zre3o4p': {
      'en': '30%',
      'ml': '30%',
    },
    'qeb28q3n': {
      'en': 'Home',
      'ml': 'വീട്',
    },
  },
  // level_mal
  {
    'wzhqxtds': {
      'en': 'Beginner',
      'ml': 'തുടക്കക്കാരൻ',
    },
    'nqr70z2e': {
      'en': 'Intermediate',
      'ml': 'ഇന്റർമീഡിയറ്റ്',
    },
    'lzes7h4h': {
      'en': 'Choose your level',
      'ml': 'നിങ്ങളുടെ ലെവൽ തിരഞ്ഞെടുക്കുക',
    },
    'xhghwein': {
      'en': 'Home',
      'ml': 'വീട്',
    },
  },
  // List_lang_inter
  {
    'fj8olegj': {
      'en': 'Languages Available',
      'ml': 'ഭാഷകൾ ലഭ്യമാണ്',
    },
    'wkkktfs8': {
      'en': '#',
      'ml': '#',
    },
    'bw4pow1i': {
      'en': 'Selected',
      'ml': 'തിരഞ്ഞെടുത്തു',
    },
    'c2msu9ij': {
      'en': 'English',
      'ml': 'ഇംഗ്ലീഷ്',
    },
    'r4l0ljxx': {
      'en': 'Malayalam',
      'ml': 'മലയാളം',
    },
    'w2tcdaya': {
      'en': 'Select Languages',
      'ml': 'ഭാഷകൾ തിരഞ്ഞെടുക്കുക',
    },
    '7zwr0c39': {
      'en': 'Select languages and let\'s get started !',
      'ml': 'ഭാഷകൾ തിരഞ്ഞെടുക്കുക, നമുക്ക് ആരംഭിക്കാം!',
    },
    'wj996jsb': {
      'en': 'Home',
      'ml': 'വീട്',
    },
  },
  // culture_choosing
  {
    'ekc7fag0': {
      'en': 'Kerala',
      'ml': 'തുടക്കക്കാരൻ',
    },
    '8m7v8c3n': {
      'en': 'United Kingdom',
      'ml': 'ഇന്റർമീഡിയറ്റ്',
    },
    '4wjycqyc': {
      'en': 'Choose the place',
      'ml': 'നിങ്ങളുടെ ലെവൽ തിരഞ്ഞെടുക്കുക',
    },
    'jtuoe636': {
      'en': 'Home',
      'ml': 'വീട്',
    },
  },
  // recording
  {
    'xpz4g4pz': {
      'en': 'Start',
      'ml': '',
    },
    'jpyam7vl': {
      'en': 'Button',
      'ml': '',
    },
    'utsufqdd': {
      'en': 'Home',
      'ml': '',
    },
  },
  // eng_dash_beginner
  {
    'sgnumqk5': {
      'en': 'Find your task...',
      'ml': 'നിങ്ങളുടെ ചുമതല കണ്ടെത്തുക...',
    },
    'zpgm66dw': {
      'en': 'Categories',
      'ml': 'വിഭാഗങ്ങൾ',
    },
    'hrqc7iad': {
      'en': 'My Modules',
      'ml': 'ചാറ്റുകൾ',
    },
    '529o2j87': {
      'en': '30%',
      'ml': '30%',
    },
    '54w0os5y': {
      'en': 'Culture  Check',
      'ml': 'സംസ്കാര പരിശോധന',
    },
    'fsbtiy8a': {
      'en': '30%',
      'ml': '30%',
    },
    'skcyx5is': {
      'en': 'Language Selection and Modules',
      'ml': 'സംസ്കാര പരിശോധന',
    },
    '05uor9kg': {
      'en': '30%',
      'ml': '30%',
    },
    'vxfz9vj4': {
      'en': 'My Tasks',
      'ml': 'എൻ്റെ ജോലികൾ',
    },
    'a0mx5y79': {
      'en': 'To do',
      'ml': 'ചെയ്യാൻ',
    },
    'bjs5ycb7': {
      'en': 'Reading',
      'ml': 'വായന',
    },
    'g8k5mors': {
      'en': 'Level 2 ',
      'ml': 'ലെവൽ 2',
    },
    '8km1wcua': {
      'en': 'Take the test',
      'ml': 'ടെസ്റ്റ് എടുക്കുക',
    },
    'x3wxq769': {
      'en': 'Listening',
      'ml': 'കേൾക്കുന്നു',
    },
    'gvd7vmse': {
      'en': 'Level 1',
      'ml': 'നില 1',
    },
    'lfn9td8q': {
      'en': 'Take the test',
      'ml': 'ടെസ്റ്റ് എടുക്കുക',
    },
    'bgj1tmaa': {
      'en': 'Completed',
      'ml': 'പൂർത്തിയാക്കി',
    },
    'uum3vhl6': {
      'en': 'Reading ',
      'ml': 'വായന',
    },
    'oiq1nxu7': {
      'en': 'Level 1',
      'ml': 'നില 1',
    },
    '7p2yhjrz': {
      'en': 'Completed',
      'ml': 'പൂർത്തിയാക്കി',
    },
    'tky6z252': {
      'en': 'Listening ',
      'ml': 'കേൾക്കുന്നു',
    },
    'susjcxb5': {
      'en': 'Level 1',
      'ml': 'നില 1',
    },
    '6g2yst7s': {
      'en': 'Completed',
      'ml': 'പൂർത്തിയാക്കി',
    },
    'wpdrb6bk': {
      'en': 'Home',
      'ml': 'വീട്',
    },
  },
  // listening
  {
    'us758hvd': {
      'en': 'Listening',
      'ml': '',
    },
    'weizcl5v': {
      'en':
          'Choose the appropriate word that matches the audio from the options below:',
      'ml': '',
    },
    'khf6wi58': {
      'en': 'Greeting',
      'ml': '',
    },
    '2b6yopce': {
      'en': 'Birthday wish',
      'ml': '',
    },
    'y7p4t9oy': {
      'en': 'House',
      'ml': '',
    },
    'gjcih4hr': {
      'en': 'School',
      'ml': '',
    },
    'zkmld2dc': {
      'en': 'motivation',
      'ml': '',
    },
    '2b5o7moz': {
      'en': 'Home',
      'ml': 'വീട്',
    },
  },
  // UnitedKingdom
  {
    '36op3bjm': {
      'en': 'United Kingdom',
      'ml': 'കേരളം',
    },
    'y45qmn8n': {
      'en': 'United Kingdom',
      'ml': 'മലയാളം',
    },
    '2vm2cs7w': {
      'en':
          'The culture of England is diverse, and defined by the cultural norms of England and the English people. Owing to England\'s influential position within the United Kingdom it can sometimes be difficult to differentiate English culture from the culture of the United Kingdom as a whole.[1] However, tracing its origins back to the early Anglo-Saxon era, England cultivated an increasingly distinct cultural heritage. This cultural development persisted throughout the subsequent Anglo-Norman era, and the reign of the Plantagenet Dynasty.\nMany scientific and technological advancements originated in England, the birthplace of the Industrial Revolution. The country has played an important role in engineering, democracy, shipbuilding, aircraft, motor vehicles, mathematics, science and sport.',
      'ml':
          'കേരളത്തിൻ്റെ സംസ്കാരം അതിൻ്റെ പാചകരീതിയിലും വസ്ത്രത്തിലും കലയിലും നൃത്തത്തിലും പ്രതിഫലിക്കുന്നു. സംസ്ഥാനത്തിൻ്റെ വാസ്തുവിദ്യയിൽ സങ്കീർണ്ണമായ കൊത്തുപണികളുള്ള ക്ഷേത്രങ്ങളും പരമ്പരാഗത തടി വീടുകളും അടയാളപ്പെടുത്തുന്നു, അതേസമയം കഥകളി, മോഹിനിയാട്ടം തുടങ്ങിയ സാഹിത്യങ്ങളും കലാരൂപങ്ങളും ലോകമെമ്പാടും ശ്രദ്ധ നേടിയിട്ടുണ്ട്. കഥകളി- ഇന്ത്യയിലെ ഏറ്റവും പ്രശസ്തമായ നൃത്തരൂപങ്ങളിലൊന്നാണിത്. ഇത് ഓപ്പറ, ബാലെ, മാസ്ക് എന്നിവയുടെ സംയോജനമാണ്.\nഹിന്ദു ഉത്സവമായ ഓണത്തിൽ വിളമ്പുന്ന സദ്യയ്ക്കും ഈ പ്രദേശം പ്രസിദ്ധമാണ്, അതിൽ പുഴുങ്ങിയ ചോറും വാഴയിലയിൽ ധാരാളം സസ്യാഹാരങ്ങളും അടങ്ങിയിട്ടുണ്ട്. നീണ്ട കടൽത്തീരമായതിനാൽ മത്സ്യം, കൊഞ്ച്, ചിപ്പികൾ, ഞണ്ട് എന്നിങ്ങനെ ധാരാളം കടൽ ഭക്ഷണങ്ങളും കേരള ഭക്ഷണരീതിയിൽ ഉണ്ട്.',
    },
    'jjcktbir': {
      'en': 'https://www.youtube.com/watch?v=1HjmA8e1JZg',
      'ml': '',
    },
    'z65fa2qq': {
      'en': 'Home',
      'ml': 'വീട്',
    },
  },
  // writing_eng_beginner
  {
    '6ason62q': {
      'en': 'Writing',
      'ml': 'വായന - 1',
    },
    'dsom0yvn': {
      'en': 'Write about your favourite hobby',
      'ml':
          'ഞാൻ എല്ലാ ദിവസവും രാവിലെ 7 മണിക്ക് ഉണരും. അത് കഴിഞ്ഞ് ഞാൻ പ്രാതൽ കഴിച്ച് ജോലിക്ക് തയ്യാറായി. ഞാൻ 8:30 AM ന് വീട്ടിൽ നിന്ന് പുറപ്പെട്ട് എൻ്റെ ഓഫീസിലേക്ക് ബസിൽ പോകുന്നു. ഞാൻ 9 AM മുതൽ 5 PM വരെ ജോലി ചെയ്യുന്നു. വൈകുന്നേരം, ഞാൻ ഒരു മണിക്കൂർ ജിമ്മിൽ പോകുന്നു. അവസാനം, ഞാൻ വീട്ടിൽ പോയി അത്താഴം കഴിച്ച് രാത്രി 10:30 ന് ഉറങ്ങാൻ പോകുന്നു.',
    },
    'm5c85wbl': {
      'en': 'Done',
      'ml': 'ചെയ്തു',
    },
    'kttcbu09': {
      'en': 'Your answer here...',
      'ml': '',
    },
    'k3hr1w46': {
      'en': 'Home',
      'ml': 'വീട്',
    },
  },
  // Speaking_Malayalam1
  {
    'xv850bac': {
      'en': 'സംസാരം-1',
      'ml': 'സംസാരിക്കുന്നത് - 1',
    },
    '5ikjx8qo': {
      'en':
          'ഭാഷയുടെ അടിസ്ഥാനത്തില്‍ \'കേരളം\' എന്ന സംസ്ഥാനം 1956 നവംബര്‍ 1 നാണ് രൂപം കൊണ്ടതെങ്കിലും പൗരാണികമായ ചരിത്രവും, കല, ശാസ്ത്രം തുടങ്ങിയ രംഗങ്ങളിലെ പാരമ്പര്യവും ഈ നാടിനെ മഹത്തരമാക്കുന്നു. സാമൂഹികാടിസ്ഥാനത്തിലുള്ള വലിയ മാറ്റങ്ങള്‍ ഇവിടെ കൊണ്ടു വരാന്‍ കഴിഞ്ഞത് സ്വന്തം സാംസ്കാരികപൈതൃകത്തിന്റെ പിന്തുണ കാരണമാണ്.',
      'ml': 'ചിത്രം തിരിച്ചറിഞ്ഞ് സംസാരിക്കുക',
    },
    'zr7huwna': {
      'en': 'Done',
      'ml': '',
    },
    'er19pvfq': {
      'en': 'Try speaking the above passage along with the given audio clip:',
      'ml': '',
    },
    'dp68v7jn': {
      'en': 'Home',
      'ml': 'വീട്',
    },
  },
  // editProfile_auth_2
  {
    'slbfg57f': {
      'en': 'Adjust the content below to update your profile.',
      'ml':
          'നിങ്ങളുടെ പ്രൊഫൈൽ അപ്‌ഡേറ്റ് ചെയ്യുന്നതിന് ചുവടെയുള്ള ഉള്ളടക്കം ക്രമീകരിക്കുക.',
    },
    'fma7m8b0': {
      'en': 'Change Photo',
      'ml': 'ചിത്രം മാറ്റുക',
    },
    '13vmo8vc': {
      'en': 'Full Name',
      'ml': 'പൂർണ്ണമായ പേര്',
    },
    '4s83gqfm': {
      'en': 'Your full name...',
      'ml': 'നിങ്ങളുടെ പൂർണ നാമം...',
    },
    '04uqkxr0': {
      'en': 'Field is required',
      'ml': 'ഫീൽഡ് ആവശ്യമാണ്',
    },
    'gx9krrrp': {
      'en': 'Please choose an option from the dropdown',
      'ml': 'ഡ്രോപ്പ്ഡൗണിൽ നിന്ന് ഒരു ഓപ്ഷൻ തിരഞ്ഞെടുക്കുക',
    },
  },
  // Miscellaneous
  {
    'r0dd1fpu': {
      'en': '',
      'ml': '',
    },
    'ky0912vw': {
      'en': '',
      'ml': '',
    },
    '5w4iapvm': {
      'en': '',
      'ml': '',
    },
    'vr4k1nc8': {
      'en': '',
      'ml': '',
    },
    'gqrg8326': {
      'en': '',
      'ml': '',
    },
    'r9rsav0a': {
      'en': '',
      'ml': '',
    },
    'u09a6z0h': {
      'en': '',
      'ml': '',
    },
    '1q93kynd': {
      'en': '',
      'ml': '',
    },
    'zgpfvtz1': {
      'en': '',
      'ml': '',
    },
    'jrif2e7w': {
      'en': '',
      'ml': '',
    },
    'sx114wh6': {
      'en': '',
      'ml': '',
    },
    'txh7inwt': {
      'en': '',
      'ml': '',
    },
    'k5jgab9j': {
      'en': '',
      'ml': '',
    },
    'fgilm4kt': {
      'en': '',
      'ml': '',
    },
    'yknwh8p7': {
      'en': '',
      'ml': '',
    },
    '454yatkw': {
      'en': '',
      'ml': '',
    },
    '44e3kqdo': {
      'en': '',
      'ml': '',
    },
    '9ez7rqyh': {
      'en': '',
      'ml': '',
    },
    'g7yn2kxu': {
      'en': '',
      'ml': '',
    },
    'vi4eiwcf': {
      'en': '',
      'ml': '',
    },
    '6p74dya2': {
      'en': '',
      'ml': '',
    },
    'asebw7i4': {
      'en': '',
      'ml': '',
    },
    'se67r7bo': {
      'en': '',
      'ml': '',
    },
    'eozh1cop': {
      'en': '',
      'ml': '',
    },
    'x1ncg3lf': {
      'en': '',
      'ml': '',
    },
    '80j17o18': {
      'en': '',
      'ml': '',
    },
    'eooww6p0': {
      'en': '',
      'ml': '',
    },
    'n793yh3e': {
      'en': '',
      'ml': '',
    },
  },
].reduce((a, b) => a..addAll(b));
