import '/flutter_flow/flutter_flow_util.dart';
import 'mal_reading_beginneer_widget.dart' show MalReadingBeginneerWidget;
import 'package:flutter/material.dart';

class MalReadingBeginneerModel
    extends FlutterFlowModel<MalReadingBeginneerWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    unfocusNode.dispose();
  }
}
