import '/flutter_flow/flutter_flow_util.dart';
import 'mal_reading_inter_widget.dart' show MalReadingInterWidget;
import 'package:flutter/material.dart';

class MalReadingInterModel extends FlutterFlowModel<MalReadingInterWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    unfocusNode.dispose();
  }
}
