import '/flutter_flow/flutter_flow_util.dart';
import 'eng_reading_inter_widget.dart' show EngReadingInterWidget;
import 'package:flutter/material.dart';

class EngReadingInterModel extends FlutterFlowModel<EngReadingInterWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    unfocusNode.dispose();
  }
}
